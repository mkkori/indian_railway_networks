import {q} from './map.js';

export function a(){
var x = 5;
var y = 6;
var z = x + y;
d3.select("p")
  .style('background','red');
}

export const b = "hello";